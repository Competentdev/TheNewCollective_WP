<div class="posts-navi row mx-auto align-items-center">

  <div class="col-10 col-sm-5 text-left text-sm-right order-sm-1">

    <?php previous_post_link('<h3>%link</h3>'); ?>

  </div><!-- /.col -->

  <div class="col-2 col-sm-1 text-center order-first order-sm-2">

    <i class="fa fa-chevron-left"></i>

  </div>

  <div class="col-2 col-sm-1 text-center order-sm-3">

    <i class="fa fa-chevron-right"></i>

  </div><!-- /.col -->

  <div class="col-10 col-sm-5 text-left order-sm-4">

    <?php next_post_link('<h3>%link</h3>'); ?>

  </div><!-- /.col -->

</div><!-- /.posts-navi -->
