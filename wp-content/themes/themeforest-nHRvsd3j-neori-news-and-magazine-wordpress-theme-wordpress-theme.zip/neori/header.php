<!DOCTYPE html>

<html <?php language_attributes(); ?>>

<head>

  <meta charset="<?php bloginfo( 'charset' ); ?>">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="theme-color" content="#29272a" />
  <meta name="msapplication-navbutton-color" content="#29272a" />
  <meta name="apple-mobile-web-app-status-bar-style" content="#29272a" />
  <meta name="description" content="<?php bloginfo('description'); ?>">

  <link rel="profile" href="http://gmpg.org/xfn/11">
  <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />

  <?php wp_head(); ?>

</head>



<body <?php body_class(); ?>>

<div id="page" class="site">



<!-- Sticky Header START -->

  <div class="sticky-header align-items-center">

    <div class="container">

      <div class="sticky-logo">

        <?php if(!get_theme_mod('neori_small_logo_image_setting')) : ?>

          <a href="<?php echo esc_url( home_url() );  ?>"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/logo-small.png" alt="logo"></a>

        <?php else : ?>

          <a href="<?php echo esc_url( home_url() );  ?>"><img src="<?php echo get_theme_mod ('neori_small_logo_image_setting', ''); ?>"></a>

        <?php endif; ?>

      </div><!-- /.sticky-logo -->

      <nav class="main-navigation sticky">

        <?php
          wp_nav_menu( array(
            'theme_location' => 'header-menu',
            'fallback_cb' => 'false',
          ) );
        ?>

      </nav><!-- /.main-navigation sticky -->

      <?php if ( function_exists('add_neori_social_share_buttons_icons') &  is_single() ) : ?> 
    
        <div class="header-share-post-single">

          <?php the_post_thumbnail('thumbnail', array('class' => 'thumbnail-header')); ?>

          <span><?php echo esc_html__('Share this article on:', 'neori'); ?></span>

          <?php echo wp_kses_post(do_shortcode('[neori-social-share-icons]')); ?>
    
        </div><!-- /.header-share-post-single-->

      <?php endif; ?>

    </div><!-- /.container-->

  </div><!-- /.sticky-header -->

<!-- Sticky Header END -->

<!-- Header Type Selection START -->

<?php if(get_theme_mod('neori_header_type_setting') == 'normal') : ?>

  <?php get_template_part( 'template-parts/headers/header-normal' ); ?>

<?php elseif(get_theme_mod('neori_header_type_setting') == 'centered') : ?>

  <?php get_template_part( 'template-parts/headers/header-centered' ); ?>

<?php elseif(get_theme_mod('neori_header_type_setting') == 'ad') : ?>

  <?php get_template_part( 'template-parts/headers/header-ad' ); ?>

<?php else : ?>

  <?php get_template_part( 'template-parts/headers/header-normal' ); ?>

<?php endif; ?>

<!-- Header Type Selection END -->

<div class="offcanvas-menu-button"><i class="fa fa-bars"></i></div>